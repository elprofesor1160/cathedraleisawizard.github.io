/*
    All info is stored under testStorage (can be changed).
    check localStorage.testStorage to see what is stored.
    storedNames is the name in which the value is stored under
    it should match the saveName in jSettings to get a callback on load.
    storageItems are for FrontPage themes, for app changes and icon images.
*/
var storageName = themeName,
    storageItems = {
        iconList: {},
        iconImageLocations: {},
        iconHolderPosition: null,
        iconBadgePosition: {},
        nocustomdrawericons: null,
        dontorganizefavs: null,
        hideapplabels: null,
        hideappbadges: null,
        alignlabelsleft: null,
        drawerLabels: {},
        drawerFavorites: [],
        badgePosition: null,
        overlayPosition: null,
        underlayPosition: null,
        underlayImage: null,
        overlayScale: null,
        underlayScale: null,
        overlayImage: null,
        labelPosition: null,
        moveAllItems: null,
        badgeSize: null,
        badgeBorderRadius: null,
        badgeImage: null,
        labelBadges: null,
        badgeFontSize: null,
        enablecolorbadges: null,
        labelFontSize: null,
        iconBorderRadius: null,
        appIcons: {}
    };

//load page storage items

// if(Number(JSON.parse(localStorage[storageName]).pageLayout) > 0){
//     for(var i = 0; i < Number(localStorage[storageName].pageLayout); i++){
//         storageItems["iconHolder" + i] = [];
//     }
// }

var storageBlock = {
    // iconOverlayImage: {
    //     saveName: 'iconOverlayImage',
    //     onload: function(storedItem){
    //         var style = "";
    //         if(storedItem){
    //             style = '.overlay{-webkit-transform:scale('+ storedItem+');}';
    //             addStyleString(style, 'iconOverlayScale');
    //         }
    //     }
    // },
    iconBorderRadius: {
        saveName: 'iconBorderRadius',
        onload: function(value){
            addStyleString('#fpplaceholder0,#fpplaceholder1,#fpplaceholder2, #fpplaceholder3,#fpplaceholder4,#fpplaceholder5,#fpplaceholder6,#fpplaceholder7,#fpplaceholder8,#fpplaceholder9,#fpplaceholder10,#fpplaceholder11,#fpplaceholder12,#fpplaceholder13,#fpplaceholder14,#fpplaceholder15,#fpplaceholder16,#fpplaceholder17,#fpplaceholder18,#fpplaceholder19,#fpplaceholder20{border-radius:'+value+'px!important;}', 'iconBorderRadius');
        }
    },
    badgeTextColor: {
        saveName: 'badgeTextColor',
        onload: function(storedItem){
            if(storedItem){
                addStyleString('.FPBadge{color:'+storedItem+'!important;}', 'badgeTextColor');
            }
        }
    },
    badgeBackgroundColor: {
        saveName: 'badgeBackgroundColor',
        onload: function(storedItem){
            if(storedItem){
                if(!lStorage.enablecolorbadges){
                    addStyleString('.FPBadge{background-color:'+storedItem+'!important;}', 'badgeBackgroundColor');  
                }
            }
        }
    },
    labelTextColor: {
        saveName: 'labelTextColor',
        onload: function(storedItem){
            if(storedItem){
                addStyleString('.FPLabel{color:'+storedItem+'!important;}', 'labelTextColor');  
            }
        }
    },
    badgePosition: {
        saveName: 'badgePosition',
        onload: function(storedItem){
            if(storedItem){
                style = '.FPBadge{margin-left:'+storedItem.left+'px;margin-top:'+storedItem.top+'px;}';
                addStyleString(style, 'badgeDragging');
            }
        }
    },
}

function initiateStorage() {
    lStorage.preload(storageBlock);
    lStorage.init({
        name: storageName,
        storageItems: storageItems,
        onloadBlock: storageBlock
    });
}
initiateStorage();

// if(Number(lStorage.pageLayout) > 0){
//     var number = Number(lStorage.pageLayout);
//     for(var i = 0; i < number-1; i++){
//         pagesController.addPage('onreload');
//     }
// }

