var Scale = "0.8"; // Change Size Widget
var Clock = "12h"; // Choose between "12h" or "24h"
var BackColor = "gray"; // Change color Background
var ShadowColor = "#fff"; // Change color Background Shadows
var TextColor = "#000"; // Change color text
var DayColor = "lightgreen"; 
var BatteryColor = "gray"; 
