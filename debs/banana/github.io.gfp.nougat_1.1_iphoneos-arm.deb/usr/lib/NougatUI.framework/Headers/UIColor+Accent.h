#import <UIKit/UIKit.h>

@interface UIColor (Accent)
// @property (copy, readonly, nonatomic) NSArray<UIColor *> *tetradicColors;
@property (strong, readonly, nonatomic) UIColor *accentColor;

@end