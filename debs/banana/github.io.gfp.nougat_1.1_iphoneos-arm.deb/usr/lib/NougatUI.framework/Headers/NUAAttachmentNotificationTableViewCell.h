#import "NUASimpleNotificationTableViewCell.h"

@interface NUAAttachmentNotificationTableViewCell : NUASimpleNotificationTableViewCell <NUADateLabelDelegate>
@property (strong, nonatomic) UIImage *attachmentImage;

@end