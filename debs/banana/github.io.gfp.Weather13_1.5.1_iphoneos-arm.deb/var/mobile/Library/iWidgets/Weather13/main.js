// Rain (rain) -
// Clock (clock) -
// Weather (weather) -
// Temperature (temp) -
// Rain + Weather (rainw) -
// Clock + Weather (timew) -
// Rain + Temperature (raint) -
// Clock + Temperature (timet) -
// Weather No Text (weathernt) -
// Temperature + Weather (tempw) -
// Weather + Temperature (weathert) -

// 1.1 Changelogs/Todo for myself
// Add debug mode -
// Customizable delay -
// Make weathert better -
// Date weekday/month/day -
// Make weather text faster to hide -

// 1.2 Changelogs/Todo for myself
// Fix weathert -
// Revamped Rain modules -
// Revamped Temperature modules -
// Fix weathert bugging out after delay -
// Make the clock bigger when using time -
// Fix 0:00 AM not showing 12:00 instead of 0:00 -

// 1.3 Changelogs/Todo for myself
// Fix massive issue causing settings not to work -

// 1.4 Changelogs/Todo for myself
// Some things were misaligned -
// Sometimes some of the widgets don't go on one line -
// Change some strings here and there so it doesn't sound as dumb :p -
// A few things didn't use the right update time and reloaded too quickly -

// 1.5 Changelogs/Todo for myself
// Hold to refresh -
// Add shadow option -
// Clean code up, and remove unnecessarry stuff -
// Widget doesn't reload when encountering an error -

// I would like to say that after all these updates I have forgotten what 90% of the code means
// Which makes it both hard to debug and update
// I also originally forgot to put comments but whatever 
// Fun story I think for like around a year or so of programming of JavaScript I never made a single comment outside of commenting code out
// As in I never put notes, I never did todo's I never explained shit, nor put funny remarks or something
// I know sad and confusing times but whatever...
// Tbh I feel like I need to remaster this after the new XenHTML API comes out.
// And make shit make sense of course.

// Code 16

//var s1 = "temp";
//var s2 = "clock";
//var debug = false;
//var noAnim = true;
//var holdTime = 500;
//var sidePadding = 20;
//var useShadow = true;
//var shadow = "medium";
//var datesetup = "wdm";
//var twelvehours = true;
//var appearance = "dark";
//var touchToReload = true;
//var useCustomShadow = false;
//var reloadspeed = "fastest";
//var customShadow = "0px 5px 10px rgba(0,0,0,0.3)";
//const weather = {
//	conditionCode: 3,
//	temperature: 10,
//	chanceofrain: 10,
//}

var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
var weathers = ["Tornado", "Tropical Storm", "Hurricane", "Severe Thunderstorm", "Thunderstorm", "Rain and Snow", "Rain and Sleet", "Snow and Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Rain", "Flurries", "Snow Showers", "Blowing Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoke", "Breezy", "Windy", "Frigid", "Cloudy", "Mostly Cloudy", "Mostly Cloudy", "Partly Cloudy", "Partly Cloudy", "Sunny", "Sunny", "Mostly Sunny", "Mostly Sunny", "Mixed Rainfall", "Hot", "Isolated Thunderstorms", "Scattered Thunderstorms", "Scattered Showers", "Heavy Rain", "Scattered Snow Showers", "Heavy Snow", "Blizzard", "Weather info failed to load"];

const widgets = {
	rain: `<div class="rain">Loading...4</div>`,
	clock: `<div class="time">9:41</div><div class="date">Friday 12 December</div>`,
	raint: `<div class="rain w">Loading...6</div><div class="raint"></div>`,
	rainw: `<div class="rain w">Loading...5</div><div class="rainw"></div>`,
	clockt: `<div class="time">9:41</div><div class="t">Friday 12 December</div>`,
	clockw: `<div class="time">9:41</div><div class="ww">Friday 12 December</div>`,
	weather: `<div class="wIcon"></div><div class="weatherC"><div class="weather">Loading...1</div></div>`,
	weatherR: `<div class="weatherC"><div class="weather r">Loading...2</div></div><div class="wIcon"></div>`,
	weatherRT: `<div class="weatherC"><div class="weather r">Loading...2</div></div><div class="wIcon" style="position:absolute !important;right:0px"></div>`,
	temperature: `<div class="temperature">Loading...3</div>`,
	temperatureW: `<div class="tempC"><div class="temperature">10&deg</div><div class="tempw">Loading...7</div></div>`,
	temperatureWR: `<div class="tempC"><div class="temperature">Loading...8</div><div class="tempw r">Loading...</div></div>`,
}

function reloadDebugWeather() {
	debugText()
}

function debugText() {
	Array.from(document.querySelectorAll('.debug')).forEach(el => el.remove());
	log("reload: <button onclick='window.location.reload()'>Reload</button>")
	log("reloadWeather: <button onclick='reloadDebugWeather()'>Reload</button>")
	log("s1: " + s1)
	log("s2: " + s2)
	log("12hr: " + twelvehours)
	log("delay: " + delay)
	log("datesetup: " + datesetup)
	log("appearance: " + appearance)
	log("sidePadding: " + sidePadding)
	log("temperature: " + weather.temperature)
	log("chanceofrain: " + weather.chanceofrain)
	log("conditionCode: " + weather.conditionCode)
}

setTimeout(() => {
	if (debug) {
		debugText()
	}
}, 200)
var $ = document;
var delay = 30000;

if (touchToReload) {
	var reloadTimeout;
	$.addEventListener("touchstart", () => {
		widget.style.transform = "scale(0.98)";
		reloadTimeout = setTimeout(() => {
			if (!noAnim) {
				widget.style.top = "15px";
				widget.style.opacity = "0.0";
				widget.style.transform = "scale(0.8)";
				
				setTimeout(() => {
					window.location.reload()
				}, 300)
				return;
			}
			window.location.reload()
		}, holdTime)
	})

	$.addEventListener("touchend", () => {
		widget.style.transform = "scale(1.0)";
		clearTimeout(reloadTimeout)
	})
}

if (reloadspeed === "performance") {
	delay = 60000;
} else if (reloadspeed === "fast") {
	delay = 30000;
} else if (reloadspeed === "fastest") {
	delay = 10000;
}

if (useShadow && !useCustomShadow) {
	if (shadow === "heavy") {
		widget.style.filter = "drop-shadow(0px 5px 3px rgba(0,0,0,0.4)";
	} else if (shadow === "medium") {
		widget.style.filter = "drop-shadow(0px 5px 5px rgba(0,0,0,0.3)";
	} else if (shadow === "light") {
		widget.style.filter = "drop-shadow(0px 5px 5px rgba(0,0,0,0.2)";
	} else if (shadow === "minimal") {
		widget.style.filter = "drop-shadow(0px 5px 2px rgba(0,0,0,0.1)";
	}
} else if (useCustomShadow) {
	widget.style.filter = `drop-shadow(${customShadow})`;
}

if (noAnim) {
	widget.style.top = "0px";
	widget.style.opacity = "1.0";
	widget.style.transform = "scale(1.0)";
} else {
	setTimeout(() => {
		widget.style.top = "0px";
		widget.style.opacity = "1.0";
		widget.style.transform = "scale(1.0)";
	}, 1000)
}



try {
	setTimeout(() => {
		if (appearance === "dark") {
			setVariable("mainColor", "black")
			for (let i = 0; i < $.querySelectorAll(".wIcon").length; i++) {
				$.querySelectorAll(".wIcon")[i].style.filter = "invert(0)"
			}
		} else if (appearance === "light") {
			setVariable("mainColor", "white")
			for (let i = 0; i < $.querySelectorAll(".wIcon").length; i++) {
				$.querySelectorAll(".wIcon")[i].style.filter = "invert(1)"
			}
		}
		setVariable("sidePadding", sidePadding + "px")
	}, 800)
} catch (err) {
	logIfDebug("Code -1<br>" + err)
}

if (debug) {
	widget.style.display = "none";
}

function log(l) {
	$.body.innerHTML += "<div class='debug'>" + l + "</div>";
	console.log(l)
}

function logIfDebug(l) {
	if (debug) {
		log(l)
	}
}

function setVariable(variable, value) {
	$.documentElement.style.setProperty('--' + variable, value);
}

function loadSides() {
	setClock("s1")
	try {
		switch (s1) {
			case "weather":
				setWeather("s1", false, false)
				break;
			case "weathernt":
				setWeather("s1", false, false, true)
				break;
			case "weathert":
				setWeather("s1", true, false)
				break;
			case "clock":
				setClock("s1")
				break;
			case "time":
				setClock("s1", true)
				break;
			case "timew":
				setClock("s1", "w")
				break;
			case "timet":
				setClock("s1", "t")
				break;
			case "temp":
				setTemp("s1")
				break;
			case "tempw":
				setTempW("s1")
				break;
			case "rain":
				setRain("s1")
				break;
			case "rainw":
				setRainW("s1")
				break;
			case "raint":
				setRainT("s1")
				break;
			default:
				console.error("Unknown value for variable 's1'")
				break;
		}
	} catch (err) {
		logIfDebug("Code 0<br>" + err)
		if (!debug) {
			window.location.reload();
		}
	}	
	try {
		switch (s2) {
			case "weather":
				setWeather("s2", false, true)
				break;
			case "weathernt":
				setWeather("s2", false, true, true)
				break;
			case "weathert":
				setWeather("s2", true, true)
				break;
			case "clock":
				setClock("s2")
				break;
			case "time":
				setClock("s2", true)
				break;
			case "timew":
				setClock("s2", "w")
				break;
			case "timet":
				setClock("s2", "t")
				break;
			case "temp":
				setTemp("s2")
				break;
			case "tempw":
				setTempW("s2", true)
				break;
			case "rain":
				setRain("s2")
				break;
			case "rainw":
				setRainW("s2")
				break;
			case "raint":
				setRainT("s2")
				break;
			default:
				console.error("Unknown value for variable 's1'")
				break;
		}	
	} catch (err) {
		logIfDebug("Code 1<br>" + err)
		if (!debug) {
			window.location.reload();
		}
	}	
}; setTimeout(() => {loadSides();}, 500)

function setTemp(div) {
	try {
		$.getElementById(div).innerHTML = widgets.temperature;
		startTemp();
	} catch (err) {
		logIfDebug("Code 2<br>" + err)
	}
}

function setRain(div) {
	try {
		$.getElementById(div).innerHTML = widgets.rain;
		startRain();
	} catch (err) {
		logIfDebug("Code 3<br>" + err)
	}
}

function setRainW(div) {
	try {
		$.getElementById(div).innerHTML = widgets.rainw;
		startRainW();
	} catch (err) {
		logIfDebug("Code 4<br>" + err)
	}
}

function setRainT(div) {
	try {
		$.getElementById(div).innerHTML = widgets.raint;
		startRainT();
	} catch (err) {
		logIfDebug("Code 5<br>" + err)
	}
}

function setTempW(div, value) {
	try {
		if (value) {
			$.getElementById(div).innerHTML = widgets.temperatureWR;
		} else {
			$.getElementById(div).innerHTML = widgets.temperatureW;
		}
		startTempW();
	} catch (err) {
		logIfDebug("Code 6<br>" + err)
	}
}

function startRain() {
	try {
		for (let i = 0; i < $.querySelectorAll(".rain").length; i++) {
			setInterval(() => {
				$.querySelectorAll(".rain")[i].innerHTML = weather.chanceofrain + "%";
			}, delay)
			$.querySelectorAll(".rain")[i].innerHTML = weather.chanceofrain + "%";
		}
	} catch (err) {
		logIfDebug("Code 7<br>" + err)
	}
}

function startRainW() {
	try {
		for (let i = 0; i < $.querySelectorAll(".rain").length; i++) {
			setInterval(() => {
				$.querySelectorAll(".rain")[i].innerHTML = weather.chanceofrain + "%";
				$.querySelectorAll(".rainw")[i].innerHTML = weathers[weather.conditionCode] + weather.conditionCode;
			}, delay)
			$.querySelectorAll(".rain")[i].innerHTML = weather.chanceofrain + "%";
			$.querySelectorAll(".rainw")[i].innerHTML = weathers[weather.conditionCode];
		}
	} catch (err) {
		logIfDebug("Code 8<br>" + err)
	}
}

function startRainT() {
	try {
		for (let i = 0; i < $.querySelectorAll(".rain").length; i++) {
			setInterval(() => {
				$.querySelectorAll(".rain")[i].innerHTML = weather.chanceofrain + "%";
				$.querySelectorAll(".raint")[i].innerHTML = "TEMP: " + weather.temperature + "&deg";
			}, delay)
			$.querySelectorAll(".rain")[i].innerHTML = weather.chanceofrain + "%";
			$.querySelectorAll(".raint")[i].innerHTML = "TEMP: " + weather.temperature + "&deg";
		}
	} catch (err) {
		logIfDebug("Code 9<br>" + err)
	}
}

function startTempW() {
	try {
		for (let i = 0; i < $.querySelectorAll(".temperature").length; i++) {
			setInterval(() => {
				$.querySelectorAll(".temperature")[i].innerHTML = weather.temperature + "&deg";
				$.querySelectorAll(".tempw")[i].innerHTML = weathers[weather.conditionCode];
			}, delay)
			$.querySelectorAll(".temperature")[i].innerHTML = weather.temperature + "&deg";
			$.querySelectorAll(".tempw")[i].innerHTML = weathers[weather.conditionCode];
		}
	} catch (err) {
		logIfDebug("Code 10<br>" + err)
	}
}

function setWeather(div, value, value2, value3) {
	try {
		if (value2) {
			if (value) {
				$.getElementById(div).innerHTML = widgets.weatherRT;
			} else {
				$.getElementById(div).innerHTML = widgets.weatherR;
			}
		} else {
			$.getElementById(div).innerHTML = widgets.weather;
		}
		$.getElementById(div).style.display = "flex";
		startWeather(value, value3, div, value2)
	} catch (err) {
		logIfDebug("Code 11<br>" + err)
	}
}

function setClock(div, value) {
	try {
		if (value === "w") {
			$.getElementById(div).innerHTML = widgets.clockw;
		} else if (value === "t") {
			$.getElementById(div).innerHTML = widgets.clockt;
		} else {
			$.getElementById(div).innerHTML = widgets.clock;
		}
		startClock(value, div)
	} catch (err) {
		logIfDebug("Code 12<br>" + err)
	}
}

function startTemp() {
	try {
		for (let i = 0; i < $.querySelectorAll(".temperature").length; i++) {
			setInterval(() => {
				$.querySelectorAll(".temperature")[i].innerHTML = weather.temperature + "&deg";
			}, delay)
			$.querySelectorAll(".temperature")[i].innerHTML = weather.temperature + "&deg";
		}
	} catch (err) {
		logIfDebug("Code 13<br>" + err)
	}
}

function startWeather(value, value2, value3, value4) {
	try {
		for (let i = 0; i < $.querySelectorAll(".weather").length; i++) {
			setInterval(() => {
//				if (!value2) {
//					if (value )
//					$.querySelectorAll(".weather")[i].innerHTML = weathers[weather.conditionCode]
//				}
				$.querySelectorAll(".wIcon")[i].style.backgroundImage = "url(icons/" + weather.conditionCode + ".png)"
				if (value) {
					$.querySelectorAll(".temp")[i].innerHTML = weathers[weather.conditionCode] + " - " + weather.temperature + ' &deg'
					$.querySelectorAll(".weather")[i].innerHTML = ""
//					if (value2) {
//					} else {
//						$.querySelectorAll(".temp")[i].innerHTML = weather.temperature + ' &deg'
//					}
				}
			}, 1000)
			if (value) {
				$.querySelectorAll(".weather")[i].innerHTML = ""
			} else {
				$.querySelectorAll(".weather")[i].innerHTML = weathers[weather.conditionCode]
			}
			$.querySelectorAll(".wIcon")[i].style.backgroundImage = "url(icons/" + weather.conditionCode + ".png)"
			if (value) {
				try {
					$.getElementById(value3).innerHTML += '<div class="temp">' + weather.temperature + '&deg</div>'
					$.querySelector("#" + value3 + " .wIcon").style.height = "54px"
					$.querySelector("#" + value3 + " .wIcon").style.width = "54px"
					$.querySelector("#" + value3 + " .wIcon").style.position = "absolute"
//					$.querySelector("#" + value3 + " .wIcon").style.left = "40px";
					if (value4) {
						$.querySelector("#" + value3 + " .wIcon").style.right = "0px";
					} else {
						$.querySelector("#" + value3 + " .wIcon").style.left = "0px";
						$.querySelector("#" + value3 + " .temp").style.top = "0px";
						$.querySelector("#" + value3 + " .temp").style.position = "absolute";
						
					}
					$.querySelector("#" + value3 + " .weather").style.position = "relative"
					$.querySelector("#" + value3 + " .weather").style.left = "35px";
					$.querySelector("#" + value3 + " .weather").style.top = "-20px";
				} catch (err) {
					logIfDebug("Code 16<br>" + err)
					if (!debug) {
						window.location.reload();
					}
				}
			}
			if (value2) {
				$.querySelectorAll(".weather")[i].remove()
			}
		}
	} catch (err) {
		logIfDebug("Code 14<br>" + err)
	}
}

function startClock(value, div) {
	try {
		for (let i = 0; i < $.querySelectorAll(".time").length; i++) {
			setInterval(() => {
				let d = new Date();
				
				let hours = d.getHours();
				let minutes = d.getMinutes()
				if (twelvehours) {
					if (hours === 0) {
						hours = 12;
					} else if (hours > 12) {
						hours = d.getHours() - 12;
					}
				}
				if (minutes < 10) {
					minutes = "0" + minutes
				}
				
				
				$.querySelectorAll(".time")[i].innerHTML = hours + ":" + minutes;
				try {
				if (!value) {
					if (datesetup === "wdm") {
						$.querySelectorAll(".date")[i].innerHTML = days[d.getDay()] + " " + d.getDate() + " " + months[d.getMonth()];
					} else if (datesetup === "wmd") {
						$.querySelectorAll(".date")[i].innerHTML = days[d.getDay()] + " " + months[d.getMonth()] + " " + d.getDate();
					}
				} else if (value === "w") {
					$.querySelectorAll(".ww")[i].innerHTML = weathers[weather.conditionCode]
				} else if (value === "t") {
					$.querySelectorAll(".t")[i].innerHTML = "TEMP: " + weather.temperature + "&deg"
				}
				} catch (err) {}
			}, 500)
			if (value && value !== "w" && value !== "t") {
				$.querySelectorAll("#" + div + " .date")[i].remove()
				$.querySelectorAll("#" + div + " .time")[i].style.fontSize = "70px"
				
			}
		}
	} catch (err) {
		logIfDebug("Code 15<br>" + err)
	}
}