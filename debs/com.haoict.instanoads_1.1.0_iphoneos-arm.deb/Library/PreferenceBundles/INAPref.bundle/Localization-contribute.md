I'm working on localization, if you like my tweak and want to help, you can help me translate to your language.

(Finished languages are here: https://github.com/haoict/instanoads/tree/master/pref/Resources)

Here are base strings

```
"APPLY" = "Apply";
"DO_YOU_REALLY_WANT_TO_KILL_INSTAGRAM" = "Do you really want to kill Instagram?";
"CONFIRM" = "Confirm";
"CANCEL" = "Cancel";
"DEFAULT" = "Default";
"MAIN_PREFERENCES" = "Main Preferences";
"NO_ADS" = "No Ads";
"REMOVE_ADS_IN_NEWS_FEED_AND_STORIES" = "Remove Ads in News Feed and Stories";
"OTHER_PREFERENCES" = "Other Preferences";
"RESET_SETTINGS" = "Reset Settings";
"SUPPORT_ME" = "Support Me";
"DONATION" = "Donation 💰";
"BUY_ME_A_COFFEE" = "Buy me a coffee";
"FEATURE_REQUEST" = "Feature Request ✨";
"SEND_ME_AN_EMAIL_WITH_YOUR_REQUEST" = "Send Me An Email With Your Request";
"SOURCE_CODE" = "Source Code 🤖";
"FOUND_A_BUG" = "Found A Bug 🐛";
"LEAVE_A_BUG_REPORT_ON_GITHUB" = "Leave A Bug Report on Github";
```

After you finished translation, Please save and name it with your language code (if you don't know, just write down your country name)

E.g: English -> en, Japanese -> ja, Vietnamese -> vi...

And your nick name, I will add to Contributors part.

Finally, send me the result to my email "hao.ict56@gmail.com" or open issue on github.
